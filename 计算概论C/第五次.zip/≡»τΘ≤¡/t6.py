# 第六题
def fact(n):
    res = 1
    for i in range(1,n+1):
        res *= i
    return res

def comb(m,n):
    return fact(m)/fact(n)/fact(m-n)

print(int(comb(6,4)))