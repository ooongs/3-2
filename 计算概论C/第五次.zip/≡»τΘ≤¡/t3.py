# 第三题
import random as rd
s = 0
n = 1000
for i in range(n):
    a = rd.randint(0,100)
    b = rd.randint(0,100)
    c = abs(a-b)
    s += c
print(f"数学期望：{s/n}")
