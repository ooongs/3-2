# 第二题
import random as rd
hongbao = 100
for i in range(1,11):
    if i != 10:
        avg = hongbao/(11-i)
        print(11-i)
        am = rd.uniform(0.01,avg)
        r_am = round(am,2)
        hongbao = hongbao - r_am
        hongbao = round(hongbao,2)
    else:
        r_am = hongbao
        hongbao = 0
        
    print(f"剩下{hongbao}元")
    print(f"第{i}个人当前抢了{r_am}元")