# 第四题
import random as rd
import math
arr = []
for k in range(10):
    s  = 0
    for i in range(6):
        s += rd.random()
    tmp = s / 6
    arr.append(tmp)

avg = sum(arr) / len(arr)
sdsq = 0
for k in arr:
    sdsq += (k - avg)**2
sd = math.sqrt(sdsq/len(arr))
print(f"平均值：{avg}，标准差：{sd}")
