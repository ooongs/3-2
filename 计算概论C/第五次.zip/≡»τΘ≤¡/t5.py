import turtle as tt
import random as rd

tt.setup(1000,1000)
a = 100
d = a/2
n = 1000
m = 0
k = -500+a
yarr = []
tt.penup()
tt.color('red')
tt.speed(0)
while k < 500:
    tt.goto(-500,k)
    tt.pendown()
    tt.goto(500,k)
    tt.penup()
    yarr.append(k)
    k += a

for i in range(1,n+1):
    x = rd.uniform(-500,500)
    y = rd.uniform(-500,k)
    ang = rd.uniform(0,360)
    tt.penup()
    tt.goto(x,y)
    tt.pendown()
    tt.color('green')
    tt.left(ang)
    tt.forward(d)
    y1 = tt.pos()[1]
    for j in yarr:
        if (j >= y and j <= y1) or (j >= y1 and j <= y):
            m += 1
            # print("xiangjiao")
            break

p = m/n
print(f"pi = {1/p}")