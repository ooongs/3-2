# 第一题
lstring = '''笔记本电脑，也是电脑"'''
cnt = 0
chdict = {}
for ch in lstring:
    if '一' <= ch <= '龥':
        cnt += 1
        if ch in chdict:
            chdict[ch] += 1
        else:
            chdict[ch] = 1
print(f"共有{cnt}个汉字")
print(f"共有{len(chdict)}个不同汉字")
print(f"每个汉字出现的个数为：{chdict}")