# 第八题
import turtle as tt
import random as rd

def graph(arr):
    l = len(arr)
    m = max(arr)
    n = l*2 + 1
    width = 1000
    height = 1000
    sp = width/n
    hp = (height-100)/m
    tt.setup(width,height)
    tt.speed(10)
    tt.penup()
    tt.goto(-width/2,-450)
    tt.pendown()
    tt.goto(width/2,-450)
    tt.penup()
    x = (-width/2) + sp
    for i in range(l):
        h = arr[i] * hp
        stick(x,h,sp)
        tt.penup()
        tt.goto(x,-480)
        tt.write(f"a[{i}]={arr[i]}")
        x += 2*sp
    tt.done

def stick(x,h,w):
    tt.penup()
    tt.goto(x,-450)
    tt.pendown()
    tt.setheading(0)
    tt.forward(w)
    tt.setheading(90)
    tt.forward(h)
    tt.setheading(180)
    tt.forward(w)
    tt.setheading(270)
    tt.forward(h)

a = [0]*13
n = 10
for i in range(10):
    x = rd.randint(1,6)
    y = rd.randint(1,6)
    s = x + y
    a[s] += 1
print(a)
graph(a)