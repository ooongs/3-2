# 第七题
def is_prime(n):
    flag = 1
    if n > 1:
        for i in range(2,n):
            if (n % i) == 0:
                flag = 0
                break
    else:
        flag = 0
    return flag

pr = []
for k in range(2,100):
    if is_prime(k) == 1:
        pr.append(k)
print(f"质数：{pr}")
print(f"共有{len(pr)}个质数")
