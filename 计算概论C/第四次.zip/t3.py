# 第三题
lstring = '''词频统计：给一段文本（可以用三引号写到程序中），统计不同汉字出现的次数。
            提示：使用for循环进行字符串的遍历，使用字典存放统计的结果。
            与字母'a'到'z'类似，一般汉字的范围是: "一"到"龥"'''
chdict = {}
for ch in lstring:
    if '一' <= ch <= '龥':
        if ch in chdict:
            chdict[ch] += 1
        else:
            chdict[ch] = 1
print(chdict)
