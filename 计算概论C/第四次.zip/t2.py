# 第二题
sdict = {}
while 1:
    s_num,age = input("输入学号和年龄：").split()
    if s_num == '0' and age =='0':
        break
    sdict[s_num] = int(age)

while 1:
    s_num = input("输入学号查询年龄：")
    if s_num == '0':
        break
    if s_num in sdict:
        print(f"{s_num}对应的年龄为：{sdict[s_num]}")
    else:
        print(f"不存在")