# 第一题
import random as rd;
import math
num = []
for i in range(100):
    x = rd.uniform(0,10)
    num.append(x)
l_n = len(num)
av = sum(num) / l_n
sdsq = 0
for k in num:
    sdsq += (k - av)**2
sd = math.sqrt(sdsq/l_n)
print(f"平均值：{av}，标准差：{sd}")