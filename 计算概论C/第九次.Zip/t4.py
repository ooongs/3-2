#coding:utf-8
import re
import urllib.request


# 获得网页内容
url = "http://www.dean.pku.edu.cn"
html = urllib.request.urlopen(url).read().decode("utf-8")
patstr = r'<a[^>]*?href="(.*?)"'
pat = re.compile(patstr)
res = []
for s in pat.findall(html):
    if s.startswith('#'):
        continue
    res.append(s)
    print(s)

# print(len(res))