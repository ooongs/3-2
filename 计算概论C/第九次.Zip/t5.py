# coding:utf-8
import requests
import re
from bs4 import BeautifulSoup

def get_html(url):
    '''获取网页'''
    return requests.get(url).text

def get_link(html):
    '''找到网页中的多P个图片'''
    soup = BeautifulSoup(html, "html.parser")
    links = soup.find_all('a',{"href": re.compile(r"http.+?")})
    res = []
    for link in links:
        print(link["href"])
        res.append(link["href"])
    return res

url = "https://bbs.pku.edu.cn/123"
html = get_html(url)
get_link(html)
