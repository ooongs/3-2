#coding:utf-8
'''三国演义人物统计'''

import jieba
import jieba.posseg
import os; 
os.chdir(os.path.dirname(__file__))
# 读取文件内容
with open("红楼梦.txt", "r", encoding='gb18030', errors='ignore') as f:
    txt = f.read()

# 分词
print("正在进行分词...")
words = jieba.posseg.lcut(txt)

# 统计人物出场次数
print("正在进行统计...")
counts = {}
for wordpair in words:
    word = wordpair.word  # 单词
    attr = wordpair.flag  # 词性
    if attr != "nr":  # 只要人名
        continue
    if len(word) == 1:  # 忽略单字
        continue
    elif word == "宝玉":
        rword = "贾宝玉"
    elif word == "黛玉":
        rword = "林黛玉"
    elif word == "凤姐" or word == "凤姐儿":
        rword = "王熙凤"
    elif word == "贾母" or word == "老太太":
        rword = "贾母"
    elif word == "宝钗":
        rword = "薛宝钗"
    elif word == "探春":
        rword = "贾探春"
    else:
        rword = word

    if rword in counts:
        counts[rword] += 1
    else:
        counts[rword] = 1

    #counts[rword] = counts.get(rword, 0) + 1

# 去掉一些词
excludes = {"将军", "却说", "荆州", "二人", "不可", "不能", "如此", "商议", "如何", "主公", "军士"}
for word in excludes:
    if word in counts:
        del (counts[word])

# 排序
items = list(counts.items())  #转成列表
items.sort(key=lambda kv: kv[1], reverse=True)

#sorted(counts.items(), key=lambda kv: kv[1], reverse=True)

# 输出
print("结果是：")
for i in range(10):
    word, count = items[i]
    print("{0:<10}{1:>5}".format(word, count))  #0表示第0个参数，<表示左对齐，10表示宽度
