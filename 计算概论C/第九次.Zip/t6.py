# coding:utf-8
import requests
from bs4 import BeautifulSoup
import matplotlib.pyplot as plt
from openpyxl import Workbook
from snownlp import SnowNLP

def get_html(url):
    '''获取页面内容'''
    data = requests.get(url).text
    return data

def get_comments(hrml):
    soup = BeautifulSoup(html, "html.parser")
    div = soup.find_all('div', {'class': 'body file-read image-click-view'})
    res = []
    for d in div:
        wenben = ""
        comments = d.find_all('p')
        for comment in comments:
            c = comment.text
            if "在 ta 的帖子中提到" in c:
                break
            wenben += ("\n" + c)
            # print(comment.text)
        res.append(wenben)
    return res
    
def cal_sentiment(wenben):
    s = SnowNLP(wenben)
    return s.sentiments

def sent_data(gentie):
    ss = []
    for wenben in gentie:
        ss.append(cal_sentiment(wenben))
    return ss

def avg_data(data):
    avg = sum(data)/len(data)
    print(f"平均情感值：{avg}")


def sent_hist(data):
    plt.hist(data)  # 绘直方图。 若加参数 density=True 则表示频率统计结果
    plt.show()

url = 'https://bbs.pku.edu.cn/v2/post-read.php?bid=22&threadid=17414500'
#网页获取
html = get_html(url)
#文本解析
gentie = get_comments(html)
#情感值计算
data = sent_data(gentie)
#数据统计
avg_data(data)
#绘图
sent_hist(data)
