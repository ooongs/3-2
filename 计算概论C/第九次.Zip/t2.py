# encoding: utf-8
import re
import os; 
os.chdir(os.path.dirname(__file__))

patstr1 = r"([0-9a-z.\-]+)@([0-9a-z]+)\.+([0-9a-z]+)"  #注意用r""的好处是：\不用写成\\
patstr2 = r"(1\d{2})-?(\d{4})-?(\d{4})"
# 读取文件内容
with open("address-material.txt", "r", encoding='utf-8', errors='ignore') as f:
    txt = f.read()

# 用compile方法将正则表达式编译得到一个pattern对象
pat1 = re.compile(patstr1)   #得到pattern对象
pat2 = re.compile(patstr2)

# 多次查找,推荐使用这种用法，功能较全面，可以取得group
print("用finditer的查找邮件结果：")
for m in pat1.finditer(txt):
    # print(m.group(),  m.start(), m.end())    #整个匹配
    # print(m.group(1),  m.start(1), m.end(1)) #第1组
    # print(m.group(2),  m.start(2), m.end(2)) #第2组
    print(m.expand(r"\1@\2.\3"))

# 直接使用findall
print("用findall的结果:", pat1.findall(txt))

print("用finditer的查找手机号结果：")
for m in pat2.finditer(txt):
    # print(m.group(),  m.start(), m.end())    #整个匹配
    # print(m.group(1),  m.start(1), m.end(1)) #第1组
    # print(m.group(2),  m.start(2), m.end(2)) #第2组
    print(m.expand(r"\1-\2-\3"))

print("用findall的结果:", pat2.findall(txt))
