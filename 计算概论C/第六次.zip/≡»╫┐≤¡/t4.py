# coding:utf-8
import turtle
import math
import random as rd


def draw_line(x1, y1, x2, y2, w):
    '''画直线。w为宽度'''
    if w < 2:
        turtle.pencolor("green")
    turtle.width(w)
    turtle.up()
    turtle.goto(x1, y1)
    turtle.down()
    turtle.goto(x2, y2)
    if w == 3:
        r = rd.uniform(5,10)
        turtle.begin_fill()
        turtle.color("red")
        turtle.circle(r)
        turtle.end_fill()
    turtle.pencolor("black")


def draw_tree(x0, y0, angle, length, level):
    '''递归地画树
    x0,y0 为生长点，angle为树干角度，length为长度，level为级别
    '''
    if level <= 0 or length < 1:
        return

    # 先画树干
    x1 = x0 + length * math.cos(angle* math.pi / 180)
    y1 = y0 + length * math.sin(angle* math.pi / 180)
    draw_line(x0, y0, x1, y1, level)

    # 再画子树。注意子树的生长点、角度、长度及级别
    a = rd.uniform(-40,-20)
    n = rd.randint(2,3)
    for _ in range(n):
        
        l = rd.uniform(0.6,1)
        draw_tree(x1, y1, angle + a, length * l, level - 1)
        if n == 2:
            a += 60
        else:
            a += 30

turtle.speed(0)
turtle.Screen().delay(0)

nTree = 4
turtle.setup(2000,1400)
xlist = [-600, -200, 200, 600]
ylist = [-400, 50, -360, 10]
for i in range(nTree):
    x = xlist[i]
    y = ylist[i]
    lvl = rd.randint(6,9)
    l = rd.uniform(80,150)
    turtle.pencolor("black")
    draw_tree(x, y, 90, l, lvl)


# 加一句保持窗口不关闭
turtle.done()
