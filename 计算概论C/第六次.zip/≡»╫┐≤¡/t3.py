#第三题
t = 15
a = 1
n = 6
for i in range(t):
    a = (2-(4-a*a)**(1/2))**(1/2)
    n = 2*n
print(f"Π = {a*n/2}")