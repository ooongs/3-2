# 第二题
n = 10000
s = [0 for _ in range(n)]

for i in range(2,n):
    for j in range(1,i):
        if i%j == 0:
            s[i] += j

for i in range(2,n):
    for j in range(i+1,n):
        if i == s[j] and j == s[i]:
            print(i, j)