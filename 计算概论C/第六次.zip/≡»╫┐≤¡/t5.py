# 第五题

def is_valid(s):
    t = 17
    sm = 0
    for i in range(len(s)):
        sm += int(s[i])*(2**t)
        t -= 1
    if sm % 11 == 1:
        return 1
    else:
        return 0

m_1993 = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
idNum = "3302211993****4914"
s = list(idNum)
for m in range(1,13):
    for d in range(1,m_1993[m-1]+1):
        if m < 10:
            s[10:12] = f'0{m}'
        else:
            s[10:12] = str(m)
        if d < 10:
            s[12:14] = f'0{d}'
        else:
            s[12:14] = str(d)
        # print(''.join(s))
        if is_valid(s) == 1:
            print(f"{m}月{d}日")
