#第一题
for bian in range(10):
    for cheng in range(10):
        for ai in range(10):
            for hao in range(10):
                if ((bian*10+cheng)+(ai*100+bian*10+cheng)+(ai*1000+hao*100+bian*10+cheng)) == 2049:
                    print(f"编：{bian}, 程：{cheng}, 爱：{ai}, 好：{hao}")
