
def fact(k):
    if k == 0:
        return 1
    else:
        res = k
        for i in range(1,k):
            res *= i
        return res

n = 10
s = 0
for k in range(n):
    tmp = fact(4*k)*(1103+26390*k)
    tmp /= (fact(k)**4)*396**(4*k)
    s += tmp
p = 9801/((8**(1/2))*s)
print(p)