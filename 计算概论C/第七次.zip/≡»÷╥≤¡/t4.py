people = {"001": ("李明",18,"aa@sina.com"), "012":("王强", 19, "bb@baidu.com"),    "051":("张静", 19, "cc@sina.com"), "031": ("王小芳", 20, "w@baidu.com"), "042":("王小芳", 20, "q@sina.com")} 
pList = []
for i in list(people):
    pList.append((i,people[i]))
pList.sort(key=lambda p: (p[1][2].split("@")[1],-p[1][1],p[1][0]))
print(pList)
