global prime
def cal_prime():
    global prime
    prime = []
    for i in range(2,100):
        flag = 0
        for j in range(2,i):
            if i % j == 0:
                flag = 1
                break
        if flag == 0:
            prime.append(i)

def is_sum(k):
    global prime
    for i in range(len(prime)):
        if prime[i] >= k:
            break
        for j in range(len(prime)):
            if prime[j] >= k:
                break
            if k == prime[i]+prime[j]:
                return prime[i],prime[j]
    return 0,0
    
cal_prime()


for i in range(2,51):
    k = 2*i
    a,b = is_sum(k)
    if a != 0 and b != 0:
        print(f"{k}={a}+{b}")

