a = 2**(1/2)
res = a / 2
n = 30
for _ in range(n):
    a = (2 + a)**(1/2)
    res *= a / 2
print(f"pi = {2/res}")
