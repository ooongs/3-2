#coding: utf-8

#%% ---------------------------------
# 第1题：统计汉字
message="""笔记本电脑，也是电脑"""
n=0
counts = {}
s = set() #!!!不能写成set(message)，否则会包含不是汉字的字符
for char in message:
    # char = char.lower() #!!!非必要
    if char<'一' or char>"龥":
        continue
    n+=1    #!!! 否则只会数重复的汉字
    if char in counts:
        counts[char] += 1
        # n+=1 #!!! 否则只会数重复的汉字
    else:
        counts[char] = 1
        s.add(char) #!!!不能写成set(message)，否则会包含不是汉字的字符
print("共有",str(n),"个汉字")
#想把字符剔除不知如何操作
print("共有", len(s), "个不重复汉字" ) #!!! counts存储的信息是不重复的汉字
print("每个汉字出现的个数",counts)


#%% ---------------------------------
# 第2题：模拟抢红包
import random
def main():
    x = 100
    # l = x #!!!不需要
    s = 10
    g = 1
    while g != s:
        t = random.uniform(0.01,2*x/(s-g+1))
        # if 0.01<t<(x-t)/s*2: #!!!使用random.uniform 即可
        print("红包金额为",round(t,2),end="  ")
        x = x - t #每打印一个红包就重新计算剩余红包额度
        g += 1
        # else:
        #     pass
    print("红包金额为",round(x,2))
if __name__ == "__main__":
    main()


#%% ---------------------------------
# 第3题：每次模拟6个数的平均值，共模拟1000次
import random
import math
s = []#建立一个空列表

for n in range(1000):
    t = 0   #!!!分配一个空间存储六个数的和
    for i in range(6):
        i = random.random()
        t += i#!!利用循环随机产生六个数并求和
        #!!!否则求出来的是最后一个随机数的两倍（i+=i）
    number = t/6#所要求的值为六个数的平均值
    s.append(number)#将值加入列表
    # print(s)
average = sum(s)/len(s)
a = 0
for n in s:
    a += (n-average) * (n-average)
sd = math.sqrt(a/len(s)) #!!!求标准差，先求（平均值-总平均值）的和，再开根求标准差
print(f"这{len(s)}个数的平均数为{average},标准差为{sd}")


# %%
