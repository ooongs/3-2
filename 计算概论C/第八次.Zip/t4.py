#coding: utf-8

import random as rd
import os; 

os.chdir(os.path.dirname(__file__))

f = open("store.txt","w",encoding="utf-8")
n = 1000
for _ in range(n):
    a = rd.randint(65,90)
    a = chr(a)
    b = str(rd.randint(1,100))
    c = str(round(rd.uniform(1,100),2))
    f.write(a+' '+b+' '+c+'\n')
f.close()

dic = {}
val = 0
f = open("store.txt","r",encoding="utf-8")
for line in f.readlines():
    [a,b,c] = line.split(' ')
    val += float(c)
    if a not in dic:
        dic[a] = [int(b),float(c)]
    else:
        [x,y] = dic[a]
        dic[a] = [x+int(b),round(y+float(c),2)]
print(dic)
print(f"总价值：{round(val,2)}")
d = sorted(dic.items(),key=lambda p: p[1][1], reverse=True)
print(f"价值最多的商品：{d[0][0]}")
f.close()