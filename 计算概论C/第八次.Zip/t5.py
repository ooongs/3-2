#coding: utf-8

import os

def includeCoding(file):
    f = open(file,"r",encoding="utf-8")
    l1 = f.readline()
    l2 = f.readline()
    if "coding" in l1 or "coding" in l2:
        return 1
    else:
        return 0

def list_files(dirpath):
    global cnt
    try:
        files = os.listdir(dirpath)
        for fname in files:
            fpath = os.path.join(dirpath, fname)
            if fname.startswith("."):
                continue

            if os.path.isfile(fpath) and fname.endswith('.py'):
                cnt += includeCoding(fpath)

    except Exception as e:
        print(e)


cnt = 0
try:
    list_files(r"./")
except Exception as e:
    print(e)
print(cnt)