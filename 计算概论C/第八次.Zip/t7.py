# 使用了mss库：pip install mss
from mss import mss
with mss() as screenshot:
    screenshot.shot(output='t7.png')