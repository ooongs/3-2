#coding: utf-8

import os; 

os.chdir(os.path.dirname(__file__))

f = open("singer.csv","r",encoding="gbk")
c = f.readline()
d = {}
for line in f.readlines():
    tmp = list(map(float,line.split(',')))
    num = int(tmp[0])
    score = tmp[1:]
    a = round(sum(score)-max(score)-min(score),1)
    d[num] = a 
f.close()
print(d)
