#coding: utf-8

import exif
import warnings
import os

def dfm2d(x):
    return round(x[0]+x[1]/60+x[2]/(60*60),5)

os.chdir(os.path.dirname(__file__))
warnings.filterwarnings("ignore")

f = open('pku_lake.jpg','rb')
imgData = exif.Image(f)

print(f"拍摄时间：{imgData.datetime_original}")

print(f"拍摄地点-经度：{dfm2d(imgData.gps_longitude)}；纬度：{dfm2d(imgData.gps_latitude)}")
print(f"相机及类型：{imgData.make}, {imgData.model}")

f.close()