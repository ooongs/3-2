#coding: utf-8

import os

os.chdir(os.path.dirname(__file__))

f = open("survey.txt","r",encoding="utf-8")
c = f.readline()
l = []
res = []
for line in f.readlines():
    tmp = line.split('\t')
    l.append(tmp[1:])
for j in range(len(l[0])):
    d = {}
    for i in range(len(l)):
        c = l[i][j]
        if c[0] in d:
            d[c[0]] += 1
        else:
            d[c[0]] = 1
    if 'A' not in d:
        d['A'] = 0
    if 'B' not in d:
        d['B'] = 0
    if 'C' not in d:
        d['C'] = 0
    res.append(d)
i = int(input())
print(res[i-1])
f.close()