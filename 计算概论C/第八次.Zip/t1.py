#coding: utf-8

import random as rd
import os; 

os.chdir(os.path.dirname(__file__))

f1 = open("t1-1.txt",'w',encoding="utf-8")
for _ in range(100):
    n = rd.uniform(0,1)
    f1.write(str(n)+'\n')
f1.close()

l = []
f2 = open("t1-1.txt",'r',encoding="utf-8")
for _ in range(100):
    f = f2.readline()
    l.append(float(f))
f2.close()

f3 = open("t1-2.txt",'w',encoding="utf-8")
avg = sum(l)/len(l)
f3.write(str(avg))
f3.close()